ZYBERLANE BRAND KIT | V1.0.0-draft.1
Review exports, not a production release.
Canonical mark and original wordmark: do not redraw or distort.
Social avatars: square canvas, 54% width, circle-safe.
Use the PDF brand book and tokens to preserve consistency.
Print proofs, 3D import, and Lottie runtime testing are pending.
Source: github.com/diluxlane/Zyberlane-Website-New/tree/feat/brand-kit
